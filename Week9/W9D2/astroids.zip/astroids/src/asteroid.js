const MovingObject = require('./moving_object.js');
const Util = require('./util.js');

function Asteroid(pos) {
    
    MovingObject.call(this, {
        pos: pos,
        vel: Util.randomVec(10),
        radius: Asteroid.RADIUS,
        color: Asteroid.COLOR
    });
}

Asteroid.RADIUS = 10
Asteroid.COLOR = '#FF0000'

Util.inherits(Asteroid, MovingObject)

// const Util = {
//     inherits(childClass, parentClass) {
//     function Surrogate() {};
//     Surrogate.prototype = parentClass.prototype;
//     childClass.prototype = new Surrogate();
//     childClass.prototype.constructor = childClass;
//     }
// }

module.exports = Asteroid;