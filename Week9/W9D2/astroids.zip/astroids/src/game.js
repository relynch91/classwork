//import { __esModule } from "../dist/main";

const Asteroid = ("./asteroid.js");
const MovingObject = ("./moving_object.js");

function Game() {
    //this.positions = addAsteroids(); //Array of positions
    this.current_asteroids = [];
    // for (let i = 0; i <= NUM_ASTEROIDS; i++) {
    //     let pos = positions[i];
    //     let asteroid = new Asteroid(pos);
    //     current_asteroids.push(asteroid);
    // }
}

// Game.DIM_X = canvasEl.width;
// Game.DIM_Y = canvasEl.height;
// Game.NUM_ASTEROIDS = 10;

// Game.prototype.addAsteroids = function() {
//     let count = 0
//     let positions = []
//     while (count < NUM_ASTEROIDS) {
//         let position = randomPositions();
//         positions.push(position)
//         count += 1;
//     }
//     return positions; 
// };

// Game.prototype.randomPositions = function() {
//     let x = Math.floor(Math.random() * Math.floor(500));
//     let y = Math.floor(Math.random() * Math.floor(500));
//     return [x, y];
// }

// Game.prototype.draw = function(ctx) {
//     ctx.clearRect(0, 0, canvasEl.width, canvasEl.height);
//     this.current_asteroids.forEach(asteroid_draw => {
//         debugger 
//         MovingObject.prototype.draw.call(asteroid_draw, ctx)
//     });   
// }

module.exports = Game;