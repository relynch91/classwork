function MovingObject(options) {
    this.pos = options["pos"];
    this.vel = options["vel"];
    this.radius = options["radius"];
    this.color = options["color"];
} 

MovingObject.prototype.draw = function(ctx) {
    let x = this.pos[0];
    let y = this.pos[1];
    ctx.fillStyle = this.color;
    ctx.beginPath();

    ctx.arc(
        x,
        y,
        this.radius,
        0,
        2 * Math.PI,
        false
    );
    ctx.fill();
};

MovingObject.prototype.move = function() {
    let x = this.pos[0];
    let y = this.pos[1];
    let velx = this.vel[0];
    let vely = this.vel[1];
    this.pos = [(x + velx), (y + vely)];

}

module.exports = MovingObject;