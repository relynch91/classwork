// console.log("Webpack is working!")

const MovingObject = require("./moving_object.js");
const Util = require('./util.js');
const Asteroid = require('./asteroid.js');
const Game = require('./game.js');

window.MovingObject = MovingObject;
window.Asteroid = Asteroid;
window.Game = Game;

window.addEventListener('DOMContentLoaded', () => {
    const canvasEl = document.getElementById("game-canvas");
    const ctx = canvasEl.getContext("2d");
    window.canvasEl = canvasEl;
    window.ctx = ctx
});