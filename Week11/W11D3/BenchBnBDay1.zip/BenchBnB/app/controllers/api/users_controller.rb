class Api::UsersController < ApplicationController

  def create
    @user = User.create(user_params)
    if @user.save!
      log_in(@user)
      render json: @user
    else
      flash[:errors] = @user.errors.full_messages
      redirect_to new_session_url
    end
  end

  private
  
  def user_params
    params.require(:user).permit(:username, :password)
  end

end
