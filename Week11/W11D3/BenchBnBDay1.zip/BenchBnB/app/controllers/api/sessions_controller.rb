class Api::SessionsController < ApplicationController
    def create 
        @user = User.find_by_credentials(
            params[:user][:username],
            params[:user][:password]
        )
        if @user
            log_in(@user)
            redirect_to user_url(@user)
        else
            flash.now[:errors] = ["Invalid username or Password"]
        end
    end

    def destroy
        if logged_in?
            log_out 
            render {}
        else
            render json: status: 404
        end
    end
end
