class User < ActiveRecord::Migration[5.2]
  def change
    #add_column :users, :username #writing new migration for changing table columns...
    # remove_column :users, :email
  end
end
