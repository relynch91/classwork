class ProjectAssignment < ApplicationRecord
end
