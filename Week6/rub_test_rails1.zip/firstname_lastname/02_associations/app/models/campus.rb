class Campus < ApplicationRecord
  self.table_name = 'campuses' # otherwise Rails looks for a 'campus' table
end
