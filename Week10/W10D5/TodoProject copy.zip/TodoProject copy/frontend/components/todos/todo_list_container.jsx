import React from 'react';
import {connect} from 'react-redux';
import ToDoList from './todo_list';
import {allTodos} from '../../reducers/selectors'

const mapStateToProps = (state) => ({
//  todos: Object.keys(state.todos).map((id) => state.todos[id])
    todos: allTodos(state)
})

const mapDispatchToProps = (dispatch) => ({
    receiveTodo: todo => dispatch(receiveTodo(todo)),
    fetchTodos: () => dispatch(fetchTodos()),
    addTodo: (todo) => dispatch(addTodo(todo))
});

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(ToDoList);