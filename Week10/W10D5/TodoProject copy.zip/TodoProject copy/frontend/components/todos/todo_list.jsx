import React from 'react';
import ToDoListItem from './todo_list_item'
import TodoForm from './todo_form'



 class ToDoList extends React.Component {
     constructor(props) {
         super(props);
         this.state = {};
     }

     componentDidMount() {
         this.props.fetchTodos();
     }
     
    render() {
        const theProps = this.props
        console.log("theprops", theProps);

        return (
            <div>
                <h1>To Do's Go Here: </h1>
                <ul>
                    {theProps.todos.map((todoObj, idx) => {
                        return (
                            <ToDoListItem key={idx} todo={todoObj} />
                        )
                    })}
                </ul>
                <TodoForm receiveTodo={theProps.receiveTodo}/>
            </div>
        )
    }
}

export default ToDoList;


// export default (props) => {

//     // componentDidMount

//     return (
//         <div>
//             <h1>To Do's Go Here: </h1>
//             <ul>
//                 {props.todos.map((todoObj, idx) => {
//                     return (
//                     <ToDoListItem key={idx} todo={todoObj} />
//                     )
//                 })}
//             </ul>
//             <TodoForm receiveTodo={props.receiveTodo} />
//         </div>
//     )
// }