import React from 'react';
import uniqueId from "../../util/todouniqueid";

class ToDoForm extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            id: uniqueId(),
            title: "",
            body: "",
            done: false
        }
        this.updateTitle = this.updateTitle.bind(this)
        this.updateBody = this.updateBody.bind(this)
        this.handleSubmit = this.handleSubmit.bind(this)
    }

    handleSubmit(event) {
        event.preventDefault();
        this.setState({id: uniqueId()})
        this.props.receiveTodo(this.state);
        this.props.addTodo(this.state)
    }

    updateTitle(event) {
        this.setState({title: event.currentTarget.value })
    }

    updateBody(event) {
        this.setState({body: event.currentTarget.value })
    }
    
    render(){
       return(
           <div>
               <h1>Update Todo:</h1>
               <form onSubmit={this.handleSubmit}>
                   <label> Title:
                       <input onChange={this.updateTitle} value={this.state.title}/>
                   </label>

                   <label> Body:
                      <input onChange={this.updateBody} value={this.state.body} />
                   </label>
                   <button>submit</button>
               </form>
           </div>
       )
    }
}
export default ToDoForm;
