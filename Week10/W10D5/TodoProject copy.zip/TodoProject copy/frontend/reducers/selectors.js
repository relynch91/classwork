export const allTodos = (state) => {
    const theKeys = Object.keys(state.todos);
    // console.log("the state:", state)
    // console.log("state.todos", state.todos)
    // console.log("the Keys:", theKeys);
    return theKeys.map((key) =>  state.todos[key])
    
    // console.log("state.todos[key]", state.todos[key])
}
window.allTodos = allTodos;