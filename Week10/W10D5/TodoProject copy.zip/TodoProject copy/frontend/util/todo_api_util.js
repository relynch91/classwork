// $.ajax({
//     method: 'GET',
//     url: '/api/todos'
// }).then(
//     todos => console.log(todos),
//     error => console.log(error)
// );

export const fetchTodos = () => {
    return $.ajax({
        url: '/api/todos',
        method: 'GET'
    });
};

export const addTodo = (todo) => {
    return $.ajax({
        url: '/api/todos',
        method: 'POST',
        data: todo
    })
}