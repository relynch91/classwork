import * as apiUtil from '../util/todo_api_util';
export const RECEIVE_TODO = "RECEIVE_TODO";
export const RECEIVE_TODOS = "RECEIVE_TODOS";

export const receiveTodos = (todos) => ({
    type: RECEIVE_TODOS,
    todos
})

export const receiveTodo = (todo) => ({
    type: RECEIVE_TODO,
    todo
})

export const fetchTodos = () => dispatch => {
    return apiUtil.fetchTodos().then(todos => dispatch(receiveTodos(todos)))
    
}

export const addToDo = (todo) => dispatch => {
    return apiUtil.addTodo(todo).then(todo => dispatch(recieveTodo(todo)))
}

// can also add getState to where we have dispatch (on line 22) but we are not using it, so we leave it off
// export const requestTodos = () => dispatch => {
//     return apiUtil.fetchTodos.then(todos => dispatch(receiveTodo(todos)))
// }

window.fetchTodos = fetchTodos;
window.addToDo = addToDo;
window.receiveTodo = receiveTodo;
window.receiveTodos = receiveTodos;
