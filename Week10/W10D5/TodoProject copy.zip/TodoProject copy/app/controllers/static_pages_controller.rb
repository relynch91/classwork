class StaticPagesController < ApplicationController
    render :root
end

